---
layout: default
title: Journal
description: Notes, ideas and lessons from the journey.
permalink: /journal/
---
<section class="page-heading"><div class="container narrow"><span class="eyebrow">DW / JOURNAL</span><h1>Ideas & insights.</h1><p class="lead">An evolving collection of short reads, perspectives and practical notes.</p></div></section>
<section class="content-section"><div class="container"><div class="posts-grid journal-grid">
{% for post in site.posts %}<a class="post-card" href="{{ post.url | relative_url }}"><span class="post-meta">{{ post.date | date: '%d %b %Y' }}{% if post.category %} / {{ post.category }}{% endif %}</span><h2>{{ post.title }}</h2><p>{{ post.description | default: post.excerpt | strip_html | truncate: 150 }}</p><span class="card-link">Read article <span>→</span></span></a>{% endfor %}
</div></div></section>
