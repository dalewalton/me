# DW — Markdown website for GitHub Pages

A responsive personal website built with **Jekyll**, **Markdown**, and a small amount of plain CSS/JavaScript. No external theme, frontend framework, Node.js, database, or paid hosting is needed.

## 1. Publish to GitHub Pages

1. Create a GitHub repository. For the simplest URL, name it **`YOUR-USERNAME.github.io`**. Alternatively use any repository name, e.g. `dw-website`.
2. Upload **the contents of this folder** to the root of your repository (not the outer `dw-markdown-site` folder). You can use **Add file → Upload files** on GitHub, or push using Git. GitHub's browser uploader may not handle hidden folders reliably, so if the `.github` workflow isn't included, create it with Git or GitHub's file editor.
3. Edit **`_config.yml`**:
   - For repository `YOUR-USERNAME.github.io`, set `url: "https://YOUR-USERNAME.github.io"` and `baseurl: ""`.
   - For repository `dw-website`, set `url: "https://YOUR-USERNAME.github.io"` and `baseurl: "/dw-website"`.
   - Change `title`, `description`, `email`, and `github_username` to suit your needs.
4. In the repository open **Settings → Pages → Build and deployment → Source**, and choose **GitHub Actions**.
5. Under **Actions**, the `Deploy Jekyll to GitHub Pages` workflow will run after a push to `main` (or you can start it manually). When it succeeds, visit the URL shown under **Settings → Pages**.

**Important:** The sample `url` and `baseurl` above must match your own repository or internal links and CSS may not load correctly.

## 2. Edit existing pages

Edit the Markdown files directly using GitHub's pencil icon:

| File | What it controls |
| --- | --- |
| `index.md` | Home page (contains HTML sections for the custom home layout) |
| `about.md` | About page (mostly Markdown) |
| `contact.md` | Contact page |
| `journal.md` | Journal index (automatically lists articles) |
| `_config.yml` | Site name, description, links, navigation |
| `assets/css/style.css` | All colours, spacing and layout |
| `assets/images/dw-mark.svg` | DW logo; editable vector graphic |
| `_includes/header.html` / `_includes/footer.html` | Site-wide navigation and footer |

All regular pages and posts use shared layouts, so you rarely need to edit HTML or CSS.

## 3. Publish a new Markdown article

Create a file inside `_posts`, named `YYYY-MM-DD-title-of-post.md`, for example:

```markdown
---
layout: post
title: "My next article"
description: "A short summary shown on the journal cards."
category: Technology
---

# Optional article heading

Write your article using **Markdown**.

## Another heading

- A bullet point
- Another point

[An example link](https://example.com)
```

Commit the file. The journal and homepage automatically show recent posts, newest first. You can delete the three sample posts once you've published your own.

## 4. Add another page

Create `resources.md` in the repository root:

```markdown
---
layout: page
title: Resources
permalink: /resources/
---

## Useful links

Write your content in Markdown.
```

Then add a nav entry in `_config.yml`:

```yaml
  - title: Resources
    url: /resources/
```

## 5. Change the blue colours

At the top of `assets/css/style.css` edit CSS variables such as `--navy`, `--blue`, `--pale`, `--border`. Some gradient accent colours are directly specified elsewhere in the CSS.

## 6. Preview locally (optional)

With Ruby and Bundler installed:

```bash
bundle install
bundle exec jekyll serve
```

Visit `http://127.0.0.1:4000`. If your project uses a `baseurl`, test via `http://127.0.0.1:4000/YOUR-REPO/`, or override it for local preview: `bundle exec jekyll serve --baseurl ""`.

## 7. Notes

- Hosting is free for public repositories on GitHub Free, subject to GitHub Pages limits.
- The Contact page does not include a form because GitHub Pages is static. Add a contact email in `_config.yml` to display a mail link.
- You own the code and can replace all sample text.
- For private repositories, verify your GitHub plan's Pages eligibility.
