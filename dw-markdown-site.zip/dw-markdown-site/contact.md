---
layout: page
title: Contact
description: Always open to thoughtful conversations and interesting ideas.
permalink: /contact/
---
## Let's start a conversation.

If something on the site interests you, I'd be glad to hear from you.

{% if site.email != '' %}
You can contact me at **[{{ site.email }}](mailto:{{ site.email }})**.
{% else %}
**Contact details coming soon.** To display your email here, add it to the `email` field in `_config.yml`.
{% endif %}

{% if site.github_username != '' %}
You can also find me on [GitHub](https://github.com/{{ site.github_username }}).
{% endif %}

Thanks for visiting!
