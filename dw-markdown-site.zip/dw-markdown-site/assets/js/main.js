const menuButton = document.querySelector('.menu-toggle');
const primaryNav = document.querySelector('.primary-nav');
if (menuButton && primaryNav) {
  menuButton.addEventListener('click', () => {
    const open = menuButton.getAttribute('aria-expanded') === 'true';
    menuButton.setAttribute('aria-expanded', String(!open));
    menuButton.setAttribute('aria-label', open ? 'Open menu' : 'Close menu');
    primaryNav.classList.toggle('is-open', !open);
  });
  primaryNav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
    primaryNav.classList.remove('is-open');
    menuButton.setAttribute('aria-expanded', 'false');
  }));
}
const year = document.querySelector('#current-year');
if (year) year.textContent = String(new Date().getFullYear());
