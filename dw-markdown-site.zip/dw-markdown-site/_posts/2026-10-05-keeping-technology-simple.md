---
layout: post
title: "Keeping technology simple"
description: "A reminder that great technical solutions are the ones people can actually use."
category: Technology
---
The most impressive solution is not always the most complicated one. A great solution should be **reliable, understandable and maintainable**.

## Choose the simplest useful tool

Be clear about the problem first. Then choose tools that are easy for the team to operate and support.

## Write things down

Good documentation reduces dependency on individuals and helps improvements survive over time.

## Design for tomorrow

A maintainable solution should be straightforward to update, test and hand over when needs change.
