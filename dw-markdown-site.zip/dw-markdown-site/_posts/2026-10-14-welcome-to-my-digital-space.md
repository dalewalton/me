---
layout: post
title: "Welcome to my digital space"
description: "Why I've created this website, and what I hope to share here."
category: Updates
---
Every worthwhile project starts somewhere. This website is my space to collect ideas, share experience and learn in public.

## Why a personal website?

I wanted something **simple, easy to maintain and entirely my own**. Somewhere I can capture useful notes, explore new ideas and revisit things I've learned.

## What comes next?

I'll be writing about technology, leadership, learning and whatever else I find interesting. Some entries will be detailed guides; others will be short reflections.

Thanks for stopping by. Here's to building something useful, one post at a time.
