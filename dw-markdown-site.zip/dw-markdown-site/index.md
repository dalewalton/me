---
layout: default
title: Home
permalink: /
---
<section class="hero">
  <div class="container hero-grid">
    <div class="hero-copy">
      <span class="eyebrow"><span class="eyebrow-line"></span> WELCOME TO MY DIGITAL SPACE</span>
      <h1>Ideas worth sharing.<br><span>Progress worth making.</span></h1>
      <p>A home for thoughtful perspectives on technology, leadership and the small improvements that make a big difference.</p>
      <div class="hero-actions"><a class="button button-primary" href="{{ '/journal/' | relative_url }}">Explore the journal <span aria-hidden="true">↗</span></a><a class="button button-secondary" href="{{ '/about/' | relative_url }}">A little about me <span aria-hidden="true">→</span></a></div>
      <div class="hero-note"><span class="blue-dot"></span> Curious by nature. Focused on what works.</div>
    </div>
    <div class="hero-graphic" aria-hidden="true"><div class="graphic-halo halo-one"></div><div class="graphic-halo halo-two"></div><div class="graphic-grid"></div><div class="graphic-frame"><span class="graphic-caption">THINK · BUILD · IMPROVE</span><span class="graphic-letters">DW<span>.</span></span><span class="graphic-rule"></span><span class="graphic-sub">A personal collection of ideas</span></div><span class="graphic-accent accent-one"></span><span class="graphic-accent accent-two"></span></div>
  </div>
</section>
<section class="feature-section"><div class="container">
  <div class="section-intro"><div><span class="eyebrow">WHAT YOU'LL FIND</span><h2>Explore what interests you.</h2></div><p>Clear thoughts, useful ideas and reflections from experience.</p></div>
  <div class="feature-grid">
    <a class="feature-card" href="{{ '/journal/' | relative_url }}"><div class="feature-icon">01<span>↗</span></div><h3>Technology</h3><p>Practical insights into digital systems, tools and the changing technology landscape.</p><span class="card-link">Read insights <span>→</span></span></a>
    <a class="feature-card" href="{{ '/about/' | relative_url }}"><div class="feature-icon">02<span>↗</span></div><h3>Leadership</h3><p>Thoughts on teams, collaboration and leading positive change.</p><span class="card-link">Get to know me <span>→</span></span></a>
    <a class="feature-card" href="{{ '/journal/' | relative_url }}"><div class="feature-icon">03<span>↗</span></div><h3>Learning</h3><p>Things I've learned, questions worth asking and ideas worth exploring.</p><span class="card-link">Explore articles <span>→</span></span></a>
  </div>
</div></section>
<section class="latest-section"><div class="container">
  <div class="section-intro"><div><span class="eyebrow">THE JOURNAL</span><h2>Latest thinking.</h2></div><a class="text-link" href="{{ '/journal/' | relative_url }}">View all articles <span>→</span></a></div>
  <div class="posts-grid">
    {% for post in site.posts limit:3 %}<a class="post-card" href="{{ post.url | relative_url }}"><span class="post-meta">{{ post.date | date: '%d %b %Y' }}{% if post.category %} / {{ post.category }}{% endif %}</span><h3>{{ post.title }}</h3><p>{{ post.description | default: post.excerpt | strip_html | truncate: 125 }}</p><span class="card-link">Read article <span>→</span></span></a>{% endfor %}
  </div>
</div></section>
<section class="cta-section"><div class="container cta-inner"><div><span class="eyebrow">LET'S CONNECT</span><h2>Have a thought to share?</h2><p>Good conversations are where great ideas begin.</p></div><a class="button button-light" href="{{ '/contact/' | relative_url }}">Get in touch <span>↗</span></a></div></section>
